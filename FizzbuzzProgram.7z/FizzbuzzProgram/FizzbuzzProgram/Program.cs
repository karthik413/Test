﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzbuzzProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 101; i++)
            {


                Console.WriteLine(i % 3 == 0 && i % 5 == 0 ? i + ":" + "fizzbuzz" : i % 3 == 0 ? i + ":" + "fizz" : i % 5 == 0 ? i + ":" + "buzz" : null);
                //Console.ReadLine(); 

            }
            Console.ReadLine();

        }
    }
}
