﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication.DTO;

namespace WebApplication.Models
{
    public class OfferService
    {
        private readonly List<Product> _inventory;

      
     }
}