﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication.DTO
{
    public class Product
    {
        //        ProductName : string
        //\ Price: decimal
        // iii) Description: string

        private readonly string _productName;
        private readonly decimal _price;
        private readonly string _description;
        public Product( string ProductName, decimal Price, string Description)
        {
            _productName = ProductName;
            _price = Price;
            _description = Description;
        }


        public string ProductName { get { return _productName; } }
        public decimal Price { get { return _price; } }
        public string Description { get { return _description; } }
    }
}