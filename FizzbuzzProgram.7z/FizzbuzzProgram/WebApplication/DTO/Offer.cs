﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication.DTO
{
    public class Offer
    {
        private readonly string _offerName;
        private readonly List<Product> _products;
        public Offer(string offerName,List<Product> products)
        {
            _offerName = offerName;
            _products = products;
        }

        public string OfferName { get { return _offerName; } }

        public List<Product> products { get { return _products; } }
    }
}